-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2022 at 04:48 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `sid` int(10) NOT NULL,
  `sname` varchar(30) NOT NULL,
  `saddress` varchar(100) NOT NULL,
  `sclass` int(10) NOT NULL,
  `sphone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`sid`, `sname`, `saddress`, `sclass`, `sphone`) VALUES
(1, 'vasu', 'chikhla lilapor valsad', 3, '8469733772'),
(16, 'ajjay mayani', 'surat ,the  IT city', 4, '9879789754'),
(17, 'abhay mayani', 'surat the hub city', 1, '1234567899'),
(18, 'darsh', 'chikhla lilapor valsad', 3, '9925434319'),
(19, 'vilince patel', 'abrama', 2, '1236547896'),
(20, 'neshal patel', 'chikhla lilapor valsad', 2, '8141628955'),
(21, 'henil', 'chikhla lilapor valsad', 1, '1456329874'),
(22, 'krish', 'vidhyanagar ,9000 hudko society', 2, '0990926636'),
(23, 'kush patel', 'sarodhi ', 3, '1236549874'),
(24, 'jalu', 'chichvada', 1, '1236547891'),
(25, 'vansh patel', 'bhagal , valsad', 3, '7043475587'),
(26, 'yash patel', 'Dungri valsda', 2, '1254653298'),
(27, 'dhavu', 'bhagal , valsad', 3, '1254879865'),
(28, 'badal patel', 'malvan', 4, '1254879862'),
(29, 'modi ji', '5421 valsad', 3, '1254788965'),
(30, 'dev', 'valsad pardi tekra fariya valsad', 4, '1254653270'),
(31, 'marmik patel', 'ronvel , valsad', 4, '8154326512');

-- --------------------------------------------------------

--
-- Table structure for table `studentclass`
--

CREATE TABLE `studentclass` (
  `cid` int(11) NOT NULL,
  `cname` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentclass`
--

INSERT INTO `studentclass` (`cid`, `cname`) VALUES
(1, 'BCA'),
(2, 'Btech'),
(3, 'Bsc'),
(4, 'Bcom');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `studentclass`
--
ALTER TABLE `studentclass`
  ADD PRIMARY KEY (`cid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `sid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `studentclass`
--
ALTER TABLE `studentclass`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
